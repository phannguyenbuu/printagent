"""Ricoh module."""
