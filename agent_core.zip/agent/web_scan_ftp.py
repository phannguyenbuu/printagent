from __future__ import annotations

from agent.web_ftp import register_ftp_routes
from agent.web_scan import register_scan_routes


def register_scan_ftp_routes(app):
    register_ftp_routes(app)
    register_scan_routes(app)
